<script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.6.2/ckeditor.js"></script>
<script src="moment.js"></script>



<?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    
    include("load.php");
    $product_name = $_POST['product_name'];
    $product_category = $_POST['product_category'];
    $product_price = $_POST['product_price'];
    $product_unit = $_POST['product_unit'];
    


  	//$img = $_FILES['img']['name'];
 $target_dir = "productimages/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    }
     else {
        $target_file="";
    }
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}

  	//$img = $_FILES['img']['name'];
 $target_dir2 = "../apanel/productpdfs/";
$target_file2 = $target_dir2 . basename($_FILES["fileToUpload2"]["name"]);
if (move_uploaded_file($_FILES["fileToUpload2"]["tmp_name"], $target_file2)) {
        //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        $target_file2="";
    }
$uploadOk = 1;
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check2 = getimagesize($_FILES["fileToUpload2"]["tmp_name"]);
    if($check2 !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}



$date = date("Y-m-d h:i:s");



    
    
    $uid = uniqid();
    

    
    $sql = "insert into products (category,name,price,unit,image,pdf,uid,hotproducts,date) values('$product_category','$product_name','$product_price','$product_unit','$target_file','$target_file2','$uid','0',NOW())";
  if(  mysqli_query($con,$sql))
  {
      echo "Product Has Been Uploaded Successfully";
  }
  else{
      echo 'error';
  }
 


  
    

    
    
    

}
?>



            <form action="admin.php?url=Add Product" method="post" class="form-horizontal" role="form" enctype="multipart/form-data">
                
                <div class="form-group">
                    <label for="category" class="col-sm-3 control-label">Product Category</label>
                    <div class="col-sm-7">
                          <select class="form-control" id="category" name="product_category">
    <option>Industrial Chemicals</option>
    <option>Plastic Bottles</option>
    <option>Plastic Jars</option>
    <option>Wooven Sack Bags (HDPE)</option>
  </select>

                


                        
                    </div>
                </div>
                
                
                
                <div class="form-group">
                    <label for="heading1" class="col-sm-3 control-label">Product Name</label>
                    <div class="col-sm-7">
                        <input type="text" id="heading1" name="product_name" placeholder="Product Name" class="form-control" autofocus required>
                
                    </div>
                </div>
                
                
                <div class="form-group">
                    <label for="heading1" class="col-sm-3 control-label">Product Price</label>
                    <div class="col-sm-7">
                        <input type="Number" id="price" name="product_price" placeholder="Product Price" class="form-control">
                
                    </div>
                </div>
                
                
                    <div class="form-group">
                    <label for="category" class="col-sm-3 control-label">Price Unit</label>
                    <div class="col-sm-7">
                          <select class="form-control" id="unit" name="product_unit">
    <option>Piece</option>
    <option>Dozen</option>
    <option>Gross</option>
    <option>Kilogram</option>
    <option>Bag</option>
    <option>Metric Tone</option>
  </select>
     
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="updateon" class="col-sm-3 control-label">Upload Product Image</label>
                    <div class="col-sm-7">
                         <input type="file" name="fileToUpload" id="fileToUpload">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="updateon" class="col-sm-3 control-label">Upload Product PDF</label>
                    <div class="col-sm-7">
                         <input type="file" name="fileToUpload2" id="fileToUpload2">
                    </div>
                </div>
                            
                
              
                 <div class="form-group">
                     
                        
                            <center>  
                 <input class="btn btn-primary" type="submit" value="Add Product">
                 </center>
                 </div>
        

            </form> <!-- /form -->
