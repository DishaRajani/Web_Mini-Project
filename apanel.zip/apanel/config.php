<?php
$surl = "https://mtp.static-codes.com/successpage.php";
$furl = "https://mtp.static-codes.com/failurepage.php";
?>