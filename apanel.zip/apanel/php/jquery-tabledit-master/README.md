# jQuery-Tabledit v1.2.3
Inline editor for HTML tables compatible with Bootstrap.


## Examples
http://markcell.github.io/jquery-tabledit/#examples


## Documentation
http://markcell.github.io/jquery-tabledit/#documentation


## Changelog
See CHANGELOG.md file.


## License
Code released under the MIT license.
