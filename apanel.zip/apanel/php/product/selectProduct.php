<?php  
include("../connection_mysqli.php");
 $output = '';  
 $sql = "SELECT * FROM `products` ORDER BY `id` DESC";  
 $result = mysqli_query($connect, $sql) or die ('error');  
 $output .= '  
      <div class="table-responsive">  
           <table id="example" class="table table-bordered">  
                <thead> <tr>  
                     <th width="5%">Id</th>  
                     <th width="13%">Category</th>
                     <th width="30%">Name</th>
                     <th width="20%">Price</th>
                     <th width="20%">Unit</th>
                     <th width="20%">Image</th>
                     <th width="20%">Pdf</th>
                     <th width="20%">Hot Products</th>
                     <th width="20%">Edit</th>
                    
                     <th width="5%">X</th>
                    
                </tr> </thead><tbody>';  
 if(mysqli_num_rows($result) > 0)  
 {  
      while($row = mysqli_fetch_array($result))  
      {  
          $checked = $row["hotproducts"];
         if($checked=="1")
         {
             $pchecked = checked;
             $uchecked = unchecked;
         }
         elseif($checked=="0")
         {
             $uchecked= checked;
             $pchecked = unchecked;
         }
           $output .= '  
                <tr>  
                     <td>'.$row["id"].'</td>  
  
                     <td class="category" data-id2="'.$row["id"].'" >'.$row["category"].'</td> 
                     <td class="name" data-id3="'.$row["id"].'" >'.$row["name"].'</td>
                     <td class="price" data-id4="'.$row["id"].'" >'.$row["price"].'</td> 
                     <td class="unit" data-id5="'.$row["id"].'" >'.$row["unit"].'</td>
                     <td class="image" data-id6="'.$row["id"].'" >'.$row["image"].'</td>
                     <td class="pdf" data-id7="'.$row["id"].'" >'.$row["pdf"].'</td>
                     <td class="hot" data-id10="'.$row["id"].'" ><fieldset id="'.$row["id"].'">
   <label><input type="radio" value="1" '.$pchecked.' onclick="btnhot('.$row["id"].',1)" name="'.$row["id"].'"> YES</label>
    <label><input type="radio" value="0" '.$uchecked.' onclick="btnhot('.$row["id"].',0)" name="'.$row["id"].'"> NO</label>
  </fieldset>
</td>

                
                     <td><button type="button" name="edit_btn" onclick="btnEdit('.$row["id"].')" data-id9="'.$row["id"].'" class="btn btn-xs btn-danger btn_edit">Edit</button></td>
                     
                     <td><button type="button" name="delete_btn" data-id8="'.$row["id"].'" class="btn btn-xs btn-danger btn_delete">x</button></td>  
                       
                </tr>  
           ';  
      }   
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="7">Data not Found</td>  
                     </tr>';  
 }  
 $output .= '</tbody></table>  
      </div>';  
 echo $output;  
 ?>  
 