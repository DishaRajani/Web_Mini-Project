<?php


$con = mysqli_connect("localhost","reliable_user","admin@123!","reliable_db");

if(!$con){
echo "error";  
}



// $sql = "select * from Demo where id = $id";
// $check = mysqli_query($con,$sql);

// while($row = mysqli_fetch_assoc($check)){
    
// }



// if(!$check){
// echo "error";  
// }
?>